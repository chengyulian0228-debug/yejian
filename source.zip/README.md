# simpleppt

把重复标题的 PDF 课件整理为连续复习讲义。暖白与暗红配色，支持电脑、平板和手机。

## 使用

1. 选择 PDF（100 MB 以内），或先试用网页内生成的示例。
2. 选择均衡、紧凑或留白版式，以及原页眉、主色或纯正文风格。
3. 可在更多设置中指定页码范围、来源显示方式。
4. 整理后对比预览，下载 PDF，在阅读器中高亮或批注。

课件不上传服务器，也不调用 AI 服务。PDF.js 在本地读取 PDF；pdf-lib 和嵌入的开源 Noto Sans SC 字体在本地输出 PDF。首次使用需要从网站加载程序、字体和 PDF.js 资源。不要将“本地处理”理解为首次打开也不需要网络。

历史记录和文件存入当前浏览器的 IndexedDB，不跨设备同步。清除网站数据或点击“清空本机记录”后记录消失；请及时下载重要讲义。关闭页面会中断未完成的整理。手机内存不足时，可在更多设置中分段整理。

## 整理边界

- 按可识别的标题编号恢复层级，同一路径的重复标题只排一次。
- 仅合并同一标题路径下完全重复的段落；保留新增条件、数字和说明。
- 正文不做语义改写或摘要。通用规则无法判断所有教师的结构，生成后应对照预览。
- 扫描页、带图的正文页、复杂矢量页、多栏页及缺少字体字形的页面保留整页原图。这些页面可能仍带原标题，且图片中的字不能直接选择。此版本不含 OCR。
- 默认隐藏原 PDF 来源页码，可选书签、文末对照或正文显示。
- 采用开源中文字体近似原字体；“保留原页眉”截取原页顶部并清理可识别的大标题，不能保证复原所有模板。

## 本地开发与检查

需要 Node.js 22.13+（推荐 24）。

```sh
npm ci
npm run dev
npm test
npm run build
node scripts/serve-static.mjs
```

最后一个命令只提供 `dist`，并在 `http://127.0.0.1:4173/yejian/` 模拟 GitHub Pages 的项目子路径。公开网站不需要 Python。

## GitHub Pages 发布

1. 新建一个空的公开仓库（建议名称 `yejian`）。上传本发布包的源码，不要上传个人课件、历史或开发缓存。
2. 仓库 Settings → Pages → Build and deployment → Source 选择 **GitHub Actions**。
3. 推送到 `main` 后，`.github/workflows/pages.yml` 会安装依赖、测试、构建并发布。
4. 等待 Actions 成功，打开该部署显示的地址，通常为 `https://用户名.github.io/yejian/`。

配置使用相对资源地址，支持任意仓库名称。GitHub 免费账号通常需使用公开仓库发布 Pages；仓库中仅包含网站代码及开源字体。访客的课件不会进入仓库。

## 依赖与字体授权

Noto Sans SC 来自 [noto-cjk](https://github.com/notofonts/noto-cjk)，采用 SIL Open Font License 1.1，见 `public/fonts/OFL.txt`。PDF.js、pdf-lib、fontkit、React、Vite、Lucide 等依赖遵循各自许可证；构建资源附带对应许可证。网站不使用远程字体、分析统计、第三方上传接口或外部 API。

`backend/`、`serve.py` 和 Python 测试属于旧本机版，仅留在原工作区作参考，不进入静态发布包。
