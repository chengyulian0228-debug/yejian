export type DocumentInfo = { id: string; name: string; size: number; pageCount: number; previewUrl: string };
export type Options = { layout: string; background: string; sourceMode: string; pages: string };
export type Job = { id: string; documentId: string; documentName: string; status: string; stage: string; progress: number; message: string; error?: string; createdAt: number; options: Options; downloadUrl?: string; stats?: { source_pages: number; result_pages: number; removed_headings: number; removed_paragraphs: number; image_pages: number; preserved_images: number } };
